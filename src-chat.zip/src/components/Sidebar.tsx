import Link from 'next/link';
import axios from 'axios';
import { useEffect, useState } from 'react';
import GroupComponent from './Groupe';
import UserComponent from './Users';

interface SidebarProps { }

const Sidebar: React.FC<SidebarProps> = () => {

  return (
    <div className="w-1/4 bg-gray-400 p-4 border-r">
      <h2 className="text-lg font-semibold mb-4">Chats</h2>
      <UserComponent />
      <GroupComponent />
    </div>
  );
};

export default Sidebar;
