import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import axios from 'axios';

const UserComponent = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        axios.get('http://localhost:5000/protected/users')
          .then(response => setUsers(response.data))
          .catch(error => console.error("Error fetching users:", error));
      } catch (err) {
        // setError('Failed to fetch users');
        console.error(err);
      } finally {
        // setLoading(false);
      }
    };

    fetchUsers();
  }, []);

  return (
    <div className="mb-4">
      <h3 className="text-sm font-semibold text-gray-500 mb-2">Direct Messages</h3>
      <ul>
        {users.map((user: any) => (
          <li key={user?.id}>
            <Link href={`/chat/${user?.username}`} className="block p-2 rounded hover:bg-gray-200">
              {user?.username}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserComponent;
