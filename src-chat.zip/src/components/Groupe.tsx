import React, { useEffect, useState } from 'react';
import Link from 'next/link';
import axios from 'axios';

const GroupComponent = () => {
  const [groups, setGroups] = useState<any[]>([]);

  useEffect(() => {
    const fetchGroups = async () => {
      try {
        const response = await axios.post('http://localhost:5000/groups', { user_id: 2 });

        setGroups(response.data);
      } catch (error) {
        console.error('Error fetching groups:', error);
      }
    };

    fetchGroups();
  }, []);

  return (
    <div>
      <h3 className="text-sm font-semibold text-gray-500 mb-2">Groups</h3>
      <ul>
        {groups.map((group) => (
          <li key={group?.id}>
            <Link href={`/chat/${group?.group_name}`} className="block p-2 rounded hover:bg-gray-200">
              {group?.group_name}
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default GroupComponent;
