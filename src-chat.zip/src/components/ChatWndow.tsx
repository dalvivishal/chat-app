import { useState, ChangeEvent, useEffect } from 'react';
import axios from 'axios';

interface ChatMessage {
  text: string;
  sender: 'me' | 'other';
  time: string;
}

interface ChatWindowProps {
  chatName: string;
  messages: ChatMessage[];
  setMessages: React.Dispatch<React.SetStateAction<ChatMessage[]>>;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ chatName, messages, setMessages }) => {
  const [input, setInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {

  }, []);

  const sendMessage = async () => {
    if (input.trim()) {
      const currentTime = new Date().toLocaleTimeString();

      const newMessage: ChatMessage = {
        text: input,
        sender: 'me',
        time: currentTime,
      };

      setMessages((prevMessages) => [...prevMessages, newMessage]);
      setInput('');

      setLoading(true);

      try {
        const response = await axios.post("http://localhost:5000/protected/send", {
          sender_id: 2,
          message: input.trim(),
          recipient_id: 1
        });
        console.log("Response send:", response.data);
      } catch (error) {
        console.error("Error sending message:", error);
      } finally {
        setLoading(false);
      }
    }
  };

  return (
    <div className="w-3/4 flex flex-col h-screen">
      <header className="bg-white p-4 border-b">
        <h2 className="text-lg font-semibold">{chatName}</h2>
      </header>
      <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
        {messages.map((msg, index) => (
          <div key={index} className={`mb-2 ${msg.sender === 'me' ? 'text-right' : 'text-left'}`}>
            <p className={`inline-block p-2 rounded-lg ${msg.sender === 'me' ? 'bg-blue-500 text-white' : 'bg-gray-300'}`}>
              {msg.text}
            </p>
            <span className="text-xs text-gray-500 ml-2">{msg.time}</span>
          </div>
        ))}
      </div>
      <footer className="p-4 bg-white border-t flex items-center">
        <input
          type="text"
          value={input}
          onChange={(e: ChangeEvent<HTMLInputElement>) => setInput(e.target.value)}
          className="flex-1 p-2 border rounded-lg mr-2"
          placeholder="Type a message..."
        />
        <button onClick={sendMessage} className={`bg-blue-500 text-white p-2 rounded-lg ${loading ? 'opacity-50 cursor-not-allowed' : ''}`} disabled={loading}>
          {loading ? 'Sending...' : 'Send'}
        </button>
      </footer>
    </div>
  );
};

export default ChatWindow;
