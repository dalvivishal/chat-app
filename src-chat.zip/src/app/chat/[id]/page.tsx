"use client";

import { useEffect, useState, createContext, useContext } from 'react';
import { useParams } from 'next/navigation';
import axios from 'axios';
import Sidebar from '@/components/Sidebar';
import ChatWindow from '@/components/ChatWndow';

interface ChatMessage {
  text: string;
  sender: 'me' | 'other';
  time: string;
}

const ChatPage = () => {
  const { id } = useParams();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMessages = async () => {
      setLoading(true);
      try {
        const response = await axios.get(`http://localhost:5000/chat/${id}`);
        messages.push({ text: response.data[0]?.message, sender: 'other', time: "12:45"});
        setMessages(messages);
        console.log("messages", response.data)
      } catch (err) {
        setError('Failed to fetch messages');
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchMessages();
  }, [id]);

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;

  return (
    <div className="flex h-screen">
      <Sidebar />
      <ChatWindow chatName={`Chat with ${id}`} messages={messages} setMessages={setMessages} />
    </div>
  );
};

export default ChatPage;
