"use client";

import { useRouter } from 'next/navigation';
import { useEffect } from 'react';
import ChatWindow from '@/components/ChatWndow';

const Home: React.FC = () => {
  const router = useRouter();

  useEffect(() => {
    router.push('/home');
  }, [router]);

  return null;
};

export default Home;
